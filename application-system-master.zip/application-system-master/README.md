# application-system
an online school appliaction system using simple html, css, javascript,php
