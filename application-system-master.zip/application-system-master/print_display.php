<?php
$localhost="127.0.0.1";
$username="root";
$password="";
$dbname="primary_db";
$conn= mysql_connect($localhost,$username,$password);
mysql_select_db($dbname,$conn);
?>
<html>
<head>
<title>Tc</title>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="col-xs-1">
     <center> <img src="logo.jpg" class="img-rounded" alt="Cinque Terre" width="100" height="100"> </center>
    </div>
    <div class="col-xs-10">
      <center><p class="small"><h2><font face="calibri">SRI RAMAKRISHNA MATRIC HIGHER SECONDARY SCHOOL </font></h2><h4><font face="calibri">(Educational Service : M/s.S.N.R Sons's Charitable Trust)</font></h4><h3><font face="calibri">S.N.R COLLEGE ROAD,COIMBATORE-641 006</font></h3><h4><font face="calibri">(Recognised by Dept. of Education, Govt of Tamilnadu)</font></h4></p></center>	
    </div>
    <div class="col-xs-1">
      <img src="srit.jpg" width="100" height="100" class="img-rounded">
    </div>
  </div>
  </div><hr>
<br><br>
<center class="small"><h2><font face="calibri">TRANSFER CERTIFICATE</font></h2></center><br><br>
