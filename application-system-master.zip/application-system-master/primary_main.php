<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
<center>
<h2>STUDENT APPLICATION SYSTEM</h2>
</center>
<blockquote>
  <blockquote>
    <p>&nbsp;  </p>
    <p>&nbsp;</p>
    <p><h3>Click on any link to continue:</h3>
    <blockquote>
      <blockquote>
        <blockquote>
          <p>&nbsp;</p>
          <p>* <a href="primary.php">Enter a new application.</a></p>
          <p>* <a href="primary_retrival.php">View a uploaded application.</a></p>
        </blockquote>
      </blockquote>
      <p>&nbsp;</p>
  </blockquote>
  </blockquote>
</blockquote>
</body>
</html>